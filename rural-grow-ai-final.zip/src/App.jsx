import React from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import Dashboard from './pages/Dashboard.jsx'
import Recommendation from './pages/Recommendation.jsx'
import Disease from './pages/Disease.jsx'
import Market from './pages/Market.jsx'
import Chat from './pages/Chat.jsx'

export default function App() {
  return (
    <div className="app">
      <nav>
        <Link to="/">Dashboard</Link> |{" "}
        <Link to="/recommendation">Recommendation</Link> |{" "}
        <Link to="/disease">Disease</Link> |{" "}
        <Link to="/market">Market</Link> |{" "}
        <Link to="/chat">Chat</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/recommendation" element={<Recommendation />} />
        <Route path="/disease" element={<Disease />} />
        <Route path="/market" element={<Market />} />
        <Route path="/chat" element={<Chat />} />
      </Routes>
    </div>
  )
}